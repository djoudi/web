
 <script src="js/bootstrap.min.js" ></script>
 <script src="js/jquery-3.3.1.min.js" ></script>
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

 <script src="js/app.js" ></script>
  </body>
</html>
